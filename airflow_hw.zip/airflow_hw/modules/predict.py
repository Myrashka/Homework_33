import json
import dill
import os
import pandas as pd

path = os.environ.get('PROJECT_PATH', '.')


def predict():
    with open(f'{path}/data/models/cars_pipe_202210241404.pkl', 'rb') as file:
        model = dill.load(file)

    df_preds = pd.DataFrame(columns=['DataFile', 'Prediction'])

    for file in os.listdir(f'{path}/data/test'):

        with open(path+'/data/test/'+file) as fin:
            test_data = json.load(fin)

        df = pd.DataFrame.from_dict([test_data])
        y = model.predict(df)

        df_to_concat = pd.DataFrame([[file, y[0]]], columns=['DataFile', 'Prediction'])
        df_preds = pd.concat([df_preds, df_to_concat], axis=0, ignore_index=True)

    df_preds.to_csv(f'{path}/data/predictions/prediction.csv', index=False)
    return (0)

if __name__ == '__main__':
    predict()